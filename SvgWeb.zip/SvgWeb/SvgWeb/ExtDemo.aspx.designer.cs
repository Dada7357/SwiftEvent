﻿//------------------------------------------------------------------------------
// <自动生成>
//     此代码由工具生成。
//
//     对此文件的更改可能会导致不正确的行为，并且如果
//     重新生成代码，这些更改将会丢失。 
// </自动生成>
//------------------------------------------------------------------------------

namespace SvgWeb {
    
    
    public partial class ExtDemo {
        
        /// <summary>
        /// form1 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        
        /// <summary>
        /// XScript1 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.XScript XScript1;
        
        /// <summary>
        /// LibraryPanel 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.TreePanel LibraryPanel;
        
        /// <summary>
        /// OutlinePanel 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Panel OutlinePanel;
        
        /// <summary>
        /// MainPanelContextMenu 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Menu MainPanelContextMenu;
        
        /// <summary>
        /// btnContextMenuUndo 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuUndo;
        
        /// <summary>
        /// btnContextMenuCut 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuCut;
        
        /// <summary>
        /// btnContextMenuCopy 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuCopy;
        
        /// <summary>
        /// btnContextMenuPaste 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuPaste;
        
        /// <summary>
        /// btnContextMenuDelete 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuDelete;
        
        /// <summary>
        /// btnContextMenuStyle 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuStyle;
        
        /// <summary>
        /// btnContextMenuBackgroud 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuBackgroud;
        
        /// <summary>
        /// btnContextMenuFillColor 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuFillColor;
        
        /// <summary>
        /// btnContextMenuGradientColor 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuGradientColor;
        
        /// <summary>
        /// btnContextMenuFontColor 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuFontColor;
        
        /// <summary>
        /// btnContextMenuLabelBackground 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuLabelBackground;
        
        /// <summary>
        /// btnContextMenuLabelBorder 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuLabelBorder;
        
        /// <summary>
        /// btnContextMenuHorizontal 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuHorizontal;
        
        /// <summary>
        /// btnContextMenuLocal 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuLocal;
        
        /// <summary>
        /// btnContextMenuLineColor 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuLineColor;
        
        /// <summary>
        /// btnContextMenuDashed 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuDashed;
        
        /// <summary>
        /// btnContextMenuHome 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuHome;
        
        /// <summary>
        /// btnContextMenuExitGroup 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuExitGroup;
        
        /// <summary>
        /// btnContextMenuEnterGroup 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuEnterGroup;
        
        /// <summary>
        /// btnContextMenuGroup 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuGroup;
        
        /// <summary>
        /// btnContextMenuUnGroup 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuUnGroup;
        
        /// <summary>
        /// btnContextMenuCollapse 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuCollapse;
        
        /// <summary>
        /// btnContextMenuExpand 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.MenuItem btnContextMenuExpand;
        
        /// <summary>
        /// MainPanel 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Panel MainPanel;
        
        /// <summary>
        /// MainPanelToolbar 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Toolbar MainPanelToolbar;
        
        /// <summary>
        /// btnView 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnView;
        
        /// <summary>
        /// btnCut 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnCut;
        
        /// <summary>
        /// btnCopy 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnCopy;
        
        /// <summary>
        /// btnPaste 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnPaste;
        
        /// <summary>
        /// btnDelete 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnDelete;
        
        /// <summary>
        /// btnUndo 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnUndo;
        
        /// <summary>
        /// btnRedo 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnRedo;
        
        /// <summary>
        /// btnBold 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnBold;
        
        /// <summary>
        /// btnItalic 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnItalic;
        
        /// <summary>
        /// btnUnderline 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnUnderline;
        
        /// <summary>
        /// btnAlign 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnAlign;
        
        /// <summary>
        /// btnFontcolor 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnFontcolor;
        
        /// <summary>
        /// btnLinecolor 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnLinecolor;
        
        /// <summary>
        /// btnFillcolor 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnFillcolor;
        
        /// <summary>
        /// btnZoom 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Button btnZoom;
        
        /// <summary>
        /// PropertyPanel 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Panel PropertyPanel;
        
        /// <summary>
        /// pgrid 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.PropertyGrid pgrid;
    }
}
